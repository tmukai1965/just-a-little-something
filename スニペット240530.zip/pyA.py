








# ii		= int(input())
# mm		= map(int, input().split())
# ll		= list(map(int, input().split()))
# lll		list(map(int, input().split()))
# rr		range
# yy		print('Yes')
# nn		print('No')
# fastio	from sys import stdin; input = stdin.readline
# zii		lambda x: int(x)-1
# dir4		((-1,0),(1,0),(0,-1),(0,1))
# dir8		((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,1),(-1,1),(1,-1))
# lim		from sys import setrecursionlimit; setrecursionlimit(10**6)
# memc		from functools import cache    #@cache
