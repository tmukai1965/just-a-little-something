

# ii		= int(input())
# mm		= map(int, input().split())
# ll		= list(map(int, input().split()))
# lll		list(map(int, input().split()))
# rr		range
# yy		print('Yes')
# nn		print('No')
# fastio	from sys import stdin; input = stdin.readline
# zii		lambda x: int(x)-1
# dir4		((-1,0),(1,0),(0,-1),(0,1))
# dir8		((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,1),(-1,1),(1,-1))
# lim		from sys import setrecursionlimit; setrecursionlimit(10**6)
# memc		from functools import cache    #@cache




# = int(input())
# = map(int, input().split())
# = list(map(int, input().split()))
# = input().split()
# from sys import stdin; input = stdin.readline
# from sys import setrecursionlimit; setrecursionlimit(10**6)
# from pypyjit import set_param; set_param('max_unroll_recursion = -1')
# from functools import cache    @cache

# import sys
# def error(*args, end="\n"):
# 	if sys.argv[-1] == 'ONLINE_JUDGE': return
# 	print('\t\t### ', *args, end=end, file=sys.stderr)

# import io, sys; _INPUT = """\
# """;
# if sys.argv[-1] != 'ONLINE_JUDGE': sys.stdin = io.StringIO(_INPUT)

# 数値と文字（文字列）を変換する (chr, ord, int, hex, oct, bin)




# serial
# import serial
# comX = 'COM4:'; bps = 115200
# ser_port = serial.Serial(comX, bps)
# def w_byte (u8)  : ser_port.write([u8])
# def w_bytes(l_u8): ser_port.write(l_u8)
# def r_byte ()    : return list(ser_port.read())[0]
# def r_bytes(n)   : return list(ser_port.read(n))



# Decimal ------------------------
from decimal import Decimal, getcontext
#getcontext().prec = 28
#print(getcontext().prec)
x = Decimal('0.1')
print(x) # 0.1000000000000000055511151231257827021181583404541015625



# ABC308-C
# C - Standings
from functools import cmp_to_key

N = int(input())
AB = [list(map(int, input().split()))+[i+1] for i in range(N)]

def cmp(s, t):
	sa=s[0]; sb=s[1]
	ta=t[0]; tb=t[1]
	ss=sa*(ta+tb)
	tt=ta*(sa+sb)
	if ss != tt: return -(ss-tt)
	return s[2]-t[2]

AB.sort(key=cmp_to_key(cmp))
ans=[]
for i in range(N): ans.append(AB[i][2])
print(*ans)
